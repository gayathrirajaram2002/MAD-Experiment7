# Adaptive ListView App

An adaptive Android application built with Kotlin that demonstrates a list-detail pattern using `SlidingPaneLayout`. The app displays a list of fruits with custom icons and shows detailed information when an item is selected.

## Features

- **Adaptive Layout**: Automatically transitions between a single-pane (list only) on phones and a two-pane (list + detail) layout on tablets and foldables.
- **Custom ListView**: Uses a custom `ArrayAdapter` to display fruit names alongside custom vector drawable icons.
- **Dynamic Details**: Updates the detail pane dynamically based on the selected item.
- **Edge-to-Edge**: Supports modern Android edge-to-edge display with proper window inset handling.
- **Back Navigation**: Integrated with `OnBackPressedDispatcher` to provide a seamless back-button experience in single-pane mode.

## Architecture

- **Traditional View System**: Built using XML layouts and `AppCompatActivity`.
- **SlidingPaneLayout**: The core component for adaptivity.
- **Vector Drawables**: High-quality, scalable fruit icons (`ic_apple`, `ic_banana`, etc.).

## How to Run

1. Open the project in **Android Studio**.
2. Sync the project with Gradle files.
3. Run the app on an emulator or physical device.
    - **Phone**: Click an item to slide the detail view into view.
    - **Tablet/Foldable**: View both the list and details side-by-side.

## Screenshot

![App Screenshot](AdaptiveListView.png)
